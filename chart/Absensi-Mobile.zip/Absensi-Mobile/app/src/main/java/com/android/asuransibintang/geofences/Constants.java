package com.android.asuransibintang.geofences;

/**
 * Created by Rachmat.Rizkihadi on 9/13/2016.
 */
public class Constants {
    public static final String Geofences = "Geofences";
    public static final String ABSEN_STATE = "ABSEN_STATE";
}
